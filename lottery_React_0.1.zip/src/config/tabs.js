const tabsConfig = [
    { id: 'personal', label: 'Fill Personal Details' },
    { id: 'bank', label: 'Fill Bank Details' },
    { id: 'dd', label: 'Fill Demand Draft Details' },
    { id: 'income', label: 'Fill Income Details' }
];

export default tabsConfig;
